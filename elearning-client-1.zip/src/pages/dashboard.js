import React from 'react'

function Dashboard() {
  return (
    <div>
      <h1 className="jumbotron p-5 mb-4">Dashboard</h1>
    </div>
  );
}

export default Dashboard